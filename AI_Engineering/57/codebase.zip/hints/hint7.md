Let's think about the content. 

This is the prompt itself. 

To get a high-quality summary, we need to be explicit.

A good prompt will tell the AI what to summarize and what to focus on.

Maybe the prompt from the last demo lesson could help.