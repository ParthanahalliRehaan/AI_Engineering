The `generateText` function returns a `response` object, and the summary text you need is on its `.text` property.

